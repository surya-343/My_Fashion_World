
-- SYSTEM REQUIREMENTS --

Hardware Requirements: 
--------------------------
-> Processor - i3
-> HDD - 500GB
-> RAM - 8GB

Software Requirements:
--------------------------
-> IDE - VS Code


Technologies Used:
--------------------------
-> HTML, CSS, JS, Bootstrap

````````````````````````````````````````````````````````````````````````````````````
How to Run WebApp?
````````````````````````````````````````````````````````````````````````````````````
Step 1: Unzip the file
Step 2: Open the folder using VSCode
Step 3: Open index.html
Step 4: Right Click and Select Open with Live Server